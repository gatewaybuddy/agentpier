from decimal import Decimal

"""Listing CRUD handlers for AgentPier."""

import json
import os
import uuid
from datetime import datetime, timezone

import boto3
from boto3.dynamodb.conditions import Key

from utils.response import success, error, not_found, unauthorized
from utils.auth import authenticate
from utils.content_filter import (
    check_listing_content,
    log_content_violation,
    get_user_violation_count,
)
from utils.rate_limit import get_client_ip
from utils.pagination import sign_cursor, verify_cursor

TABLE_NAME = os.environ.get("TABLE_NAME", "agentpier-dev")

FREE_LISTING_LIMIT = 3  # Free listings per account

VALID_TYPES = {"service", "product", "agent_skill", "consulting"}
VALID_CATEGORIES = {
    "code_review",
    "research",
    "automation",
    "monitoring",
    "content_creation",
    "security",
    "infrastructure",
    "data_processing",
    "translation",
    "trading",
    "consulting",
    "design",
    "testing",
    "devops",
    "other",
}


def _get_table():
    dynamodb = boto3.resource("dynamodb")
    return dynamodb.Table(TABLE_NAME)


def create_listing(event, context):
    """POST /listings — Create a new listing."""
    user = authenticate(event)
    if not user:
        return unauthorized()

    try:
        raw_body = event.get("body")
        if not raw_body:
            return error("Request body is required", "missing_body")
        body = json.loads(raw_body)
    except json.JSONDecodeError:
        return error("Invalid JSON body", "invalid_body")

    # Validate required fields
    listing_type = body.get("type", "service")
    if listing_type not in VALID_TYPES:
        return error(f"Invalid type. Must be one of: {VALID_TYPES}", "invalid_type")

    category = body.get("category", "").lower()
    if category not in VALID_CATEGORIES:
        return error(
            f"Invalid category. Must be one of: {VALID_CATEGORIES}", "invalid_category"
        )

    title = body.get("title", "")
    if not isinstance(title, str):
        return error("Title must be a string", "invalid_title")
    title = title.strip()
    if not title or len(title) > 200:
        return error("Title is required (max 200 chars)", "invalid_title")

    description = body.get("description", "")
    if not isinstance(description, str):
        return error("Description must be a string", "invalid_description")
    description = description.strip()
    if len(description) > 2000:
        return error("Description max 2000 chars", "invalid_description")

    # Build listing record
    listing_id = f"lst_{uuid.uuid4().hex[:12]}"
    now = datetime.now(timezone.utc).isoformat()
    user_id = user["PK"].replace("USER#", "")

    # Validate tags
    tags = body.get("tags", [])
    if not isinstance(tags, list):
        return error("Tags must be an array", "invalid_tags")
    if len(tags) > 10:
        return error("Maximum 10 tags allowed", "too_many_tags")
    clean_tags = []
    for tag in tags:
        if not isinstance(tag, str):
            return error("Tags must be strings", "invalid_tags")
        tag = tag.strip()[:30]  # Enforce 30 char max
        if tag:
            clean_tags.append(tag)

    # --- Content moderation ---
    is_clean, flagged_categories = check_listing_content(title, description, clean_tags)
    if not is_clean:
        client_ip = get_client_ip(event)
        log_content_violation(user_id, body, flagged_categories, client_ip)

        # Check for repeat offenders (3+ violations in 24h = suspended)
        violation_count = get_user_violation_count(user_id)
        if violation_count >= 3:
            return error(
                "Your account has been suspended due to repeated content policy violations. "
                "Contact support if you believe this is an error.",
                "account_suspended",
                403,
            )

        return error(
            "This listing violates AgentPier content policy. "
            "Please revise your title, description, or tags and resubmit. "
            "AgentPier is a business-focused marketplace — illegal, explicit, "
            "exploitative, or fraudulent content is not permitted.",
            "content_policy_violation",
        )

    # --- Listing limit check (3 free per account) ---
    table = _get_table()
    existing_listings = table.query(
        IndexName="GSI2",
        KeyConditionExpression=Key("GSI2PK").eq(f"AGENT#{user_id}"),
        Select="COUNT",
    )
    current_count = existing_listings.get("Count", 0)

    if current_count >= FREE_LISTING_LIMIT:
        return error(
            f"Free listing limit reached ({FREE_LISTING_LIMIT}). "
            "Upgrade your account to create additional listings.",
            "listing_limit_reached",
            402,
        )

    location = body.get("location", {})
    state = location.get("state", "").upper()
    city = location.get("city", "").lower().replace(" ", "_")

    item = {
        "PK": f"LISTING#{listing_id}",
        "SK": "META",
        # GSI1: category + location for search
        "GSI1PK": category,
        "GSI1SK": f"{state}#{city}#{listing_id}" if state else listing_id,
        # GSI2: agent index
        "GSI2PK": f"AGENT#{user_id}",
        "GSI2SK": now,
        # Data
        "listing_id": listing_id,
        "type": listing_type,
        "category": category,
        "title": title,
        "description": description,
        "location": location,
        "pricing": body.get("pricing", {}),
        "availability": body.get("availability", ""),
        "contact": body.get("contact", {}),
        "tags": clean_tags,
        "posted_by": user_id,
        "agent_name": user.get("username") or user.get("agent_name", ""),
        "human_verified": user.get("human_verified", False),
        "moltbook_verified": bool(user.get("moltbook_verified", False)),
        "moltbook_name": (
            user.get("moltbook_name", "") if user.get("moltbook_verified") else ""
        ),
        "trust_score": Decimal("0.0"),
        "status": "active",
        "created_at": now,
        "updated_at": now,
    }

    table.put_item(Item=item)

    # Update user's listing_count
    table.update_item(
        Key={"PK": f"USER#{user_id}", "SK": "META"},
        UpdateExpression="ADD listing_count :inc",
        ExpressionAttributeValues={":inc": 1},
    )

    return success(
        {
            "id": listing_id,
            "status": "active",
            "trust_score": 0.0,
            "created_at": now,
            "url": f"https://agentpier.io/listing/{listing_id}",
        },
        201,
    )


def get_listing(event, context):
    """GET /listings/{id} — Get a specific listing."""
    listing_id = event.get("pathParameters", {}).get("id", "")

    if not listing_id:
        return error("Listing ID required", "missing_id")

    table = _get_table()
    response = table.get_item(Key={"PK": f"LISTING#{listing_id}", "SK": "META"})

    item = response.get("Item")
    if not item:
        return not_found(f"Listing {listing_id} not found")

    # Strip internal fields from response
    for key in ["PK", "SK", "GSI1PK", "GSI1SK", "GSI2PK", "GSI2SK", "posted_by"]:
        item.pop(key, None)

    # Convert Decimal trust_score to float
    if "trust_score" in item:
        item["trust_score"] = float(item["trust_score"])

    return success(item)


def search_listings(event, context):
    """GET /listings?category=X&state=Y&city=Z — Search listings."""
    params = event.get("queryStringParameters") or {}

    category = params.get("category", "").lower()
    if not category:
        return error("category parameter is required", "missing_category")

    if category not in VALID_CATEGORIES:
        return error(
            f"Invalid category. Must be one of: {VALID_CATEGORIES}", "invalid_category"
        )

    state = params.get("state", "").upper()
    city = params.get("city", "").lower().replace(" ", "_")
    try:
        limit = max(1, min(int(params.get("limit", "20")), 50))
    except (ValueError, TypeError):
        limit = 20
    cursor = params.get("cursor")
    try:
        min_trust = max(0.0, min(float(params.get("min_trust", "0")), 1.0))
    except (ValueError, TypeError):
        min_trust = 0.0

    table = _get_table()

    # Build query
    key_condition = Key("GSI1PK").eq(category)
    if state and city:
        key_condition = key_condition & Key("GSI1SK").begins_with(f"{state}#{city}")
    elif state:
        key_condition = key_condition & Key("GSI1SK").begins_with(f"{state}#")

    query_kwargs = {
        "IndexName": "GSI1",
        "KeyConditionExpression": key_condition,
        "Limit": limit,
    }

    if cursor:
        # Verify the signed cursor
        decoded = verify_cursor(cursor)
        if not decoded:
            return error("Invalid pagination cursor", "invalid_cursor")

        # Additional validation - cursor must belong to the queried category
        if decoded.get("GSI1PK") != category:
            return error("Invalid pagination cursor", "invalid_cursor")

        query_kwargs["ExclusiveStartKey"] = decoded

    response = table.query(**query_kwargs)
    items = response.get("Items", [])

    # Filter by trust score (post-query for now)
    if min_trust > 0:
        items = [i for i in items if float(i.get("trust_score", 0)) >= min_trust]

    # Clean up internal fields and ensure trust_score is numeric
    for item in items:
        for key in ["PK", "SK", "GSI1PK", "GSI1SK", "GSI2PK", "GSI2SK", "posted_by"]:
            item.pop(key, None)
        # Convert Decimal trust_score to float
        if "trust_score" in item:
            item["trust_score"] = float(item["trust_score"])

    result = {
        "results": items,
        "count": len(items),
    }

    # Pagination
    last_key = response.get("LastEvaluatedKey")
    if last_key:
        result["next_cursor"] = sign_cursor(last_key)

    return success(result)


def update_listing(event, context):
    """PATCH /listings/{id} — Update a listing."""
    user = authenticate(event)
    if not user:
        return unauthorized()

    listing_id = event.get("pathParameters", {}).get("id", "")
    if not listing_id:
        return error("Listing ID required", "missing_id")

    table = _get_table()

    # Verify ownership
    existing = table.get_item(Key={"PK": f"LISTING#{listing_id}", "SK": "META"}).get(
        "Item"
    )

    if not existing:
        return not_found(f"Listing {listing_id} not found")

    user_id = user["PK"].replace("USER#", "")
    if existing.get("posted_by") != user_id:
        return error("You can only update your own listings", "forbidden", 403)

    try:
        body = json.loads(event.get("body", "{}"))
    except json.JSONDecodeError:
        return error("Invalid JSON body", "invalid_body")

    # Allowed update fields
    allowed = {
        "title",
        "description",
        "pricing",
        "availability",
        "contact",
        "tags",
        "status",
    }
    updates = {k: v for k, v in body.items() if k in allowed}

    # Type validation on text fields
    for field in ("title", "description"):
        if field in updates and not isinstance(updates[field], str):
            return error(f"{field.capitalize()} must be a string", f"invalid_{field}")

    # Content filter on text field updates
    check_title = updates.get("title", existing.get("title", ""))
    check_desc = updates.get("description", existing.get("description", ""))
    check_tags = updates.get("tags", existing.get("tags", []))
    is_clean, flagged = check_listing_content(check_title, check_desc, check_tags)
    if not is_clean:
        client_ip = get_client_ip(event)
        log_content_violation(
            user_id, {**updates, "listing_id": listing_id}, flagged, client_ip
        )
        return error(
            "This update violates AgentPier content policy. "
            "Please revise your content and resubmit.",
            "content_policy_violation",
        )

    updates["updated_at"] = datetime.now(timezone.utc).isoformat()

    # Build update expression
    update_parts = []
    values = {}
    names = {}
    for i, (key, val) in enumerate(updates.items()):
        attr = f"#attr{i}"
        placeholder = f":val{i}"
        update_parts.append(f"{attr} = {placeholder}")
        values[placeholder] = val
        names[attr] = key

    table.update_item(
        Key={"PK": f"LISTING#{listing_id}", "SK": "META"},
        UpdateExpression="SET " + ", ".join(update_parts),
        ExpressionAttributeValues=values,
        ExpressionAttributeNames=names,
    )

    return success({"id": listing_id, "updated": list(updates.keys())})


def delete_listing(event, context):
    """DELETE /listings/{id} — Remove a listing."""
    user = authenticate(event)
    if not user:
        return unauthorized()

    listing_id = event.get("pathParameters", {}).get("id", "")
    if not listing_id:
        return error("Listing ID required", "missing_id")

    table = _get_table()

    # Verify ownership
    existing = table.get_item(Key={"PK": f"LISTING#{listing_id}", "SK": "META"}).get(
        "Item"
    )

    if not existing:
        return not_found(f"Listing {listing_id} not found")

    user_id = user["PK"].replace("USER#", "")
    if existing.get("posted_by") != user_id:
        return error("You can only delete your own listings", "forbidden", 403)

    table.delete_item(Key={"PK": f"LISTING#{listing_id}", "SK": "META"})

    # Update user's listing_count
    table.update_item(
        Key={"PK": f"USER#{user_id}", "SK": "META"},
        UpdateExpression="ADD listing_count :dec",
        ExpressionAttributeValues={":dec": -1},
    )

    return success({"id": listing_id, "deleted": True})
